# Phase 2 – Requirement Analysis

## Functional Requirements

### FR1 – High Impact UI Policy
Create an Incident UI Policy named **High Impact Control**.

**Condition:**
- Field: Impact
- Operator: is
- Value: 1 – High

**Expected behavior:**
- Assignment group becomes mandatory.
- Reverse if false is enabled.

### FR2 – Urgency UI Policy Action
Create a UI Policy Action for **Urgency**.

**Configuration:**
- Field: Urgency
- Read-only: true
- Visible: unchanged

The action applies when Impact is High.

### FR3 – Automatic Urgency Update
Create an onChange Client Script on Incident.

**Configuration:**
- Name: Auto set urgency for high impact
- Table: Incident
- Type: onChange
- Field: Impact
- Active: true

When Impact becomes High, Urgency is set to High.

### FR4 – Save-Time Validation
Create an onSubmit Client Script.

**Configuration:**
- Name: Prevent save if Assigned To missing
- Table: Incident
- Type: onSubmit
- Active: true

If Impact is High and Assigned To is empty, saving must be prevented and an error displayed.

### FR5 – List Edit Restriction
Create an onCellEdit Client Script.

**Configuration:**
- Name: Prevent state change via list edit
- Table: Incident
- Type: onCellEdit
- Field: State
- Active: true

Direct list editing of State must be blocked.

## Non-Functional Requirements
- The solution should be lightweight.
- Rules should be applied consistently.
- Configuration should be easy to test.
- User feedback should be clear.
- The implementation should improve data integrity.

## Required Skills
- Incident Management
- UI Policy
- UI Policy Actions
- Client Scripts
- Form Validation
