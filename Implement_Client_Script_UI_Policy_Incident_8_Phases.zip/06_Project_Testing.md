# Phase 6 – Project Testing

## Test Case 1 – Mandatory Enforcement

**Steps:**
1. Open Incident → Create New.
2. Set Impact to High.
3. Leave Assigned To empty.
4. Click Submit.

**Expected Result:**
- Incident should not be saved.
- An error should indicate that Assigned To is required.
- UI Policy and automatic Urgency behavior should work.

## Test Case 2 – Successful Save

**Steps:**
1. Open an Incident.
2. Set Impact to High.
3. Select a user in Assigned To.
4. Click Submit.

**Expected Result:**
- Incident saves successfully.
- No validation error appears.
- Urgency is automatically set to High.
- Urgency remains read-only while the High Impact condition applies.

## Test Case 3 – Reverse Condition

**Steps:**
1. Open an Incident with Impact = High.
2. Change Impact from High to Medium.
3. Observe the fields.

**Expected Result:**
- Assignment group is no longer mandatory.
- Urgency becomes editable.
- The reverse UI Policy behavior is applied.

## Test Case 4 – List Edit Blocking

**Steps:**
1. Navigate to Incident → All.
2. Double-click the State field.
3. Attempt to change the value.

**Expected Result:**
- An alert appears.
- The State value remains unchanged.

## Test Case 5 – Form-Based State Update

**Steps:**
1. Open an Incident record.
2. Change State from the Incident form.
3. Click Update.

**Expected Result:**
- State change is saved successfully.
- Other configured Client Script and UI Policy rules continue to operate.

## Test Summary

| Test | Expected Outcome |
|---|---|
| High Impact + empty Assigned To | Save blocked |
| High Impact + Assigned To | Save successful |
| Impact High | Urgency automatically High |
| Impact High | Urgency read-only |
| Impact changed away from High | UI Policy reversed |
| State list edit | Blocked |
| State form update | Allowed |

## Final Validation
All tests should be performed in the ServiceNow instance and the observed results should be recorded before final submission.
