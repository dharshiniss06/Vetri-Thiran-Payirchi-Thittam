# Phase 4 – Project Planning

## Project Goal
Implement and validate client-side controls for Incident records in ServiceNow.

## Implementation Plan

### Step 1 – Create UI Policy
Create **High Impact Control** for the Incident table.

### Step 2 – Configure UI Policy
Set:
- Impact is 1 – High
- Assignment group mandatory
- Reverse if false = true

### Step 3 – Create UI Policy Action
Configure Urgency as read-only when the policy condition is true.

### Step 4 – Create onChange Client Script
Monitor Impact and automatically set Urgency to High when Impact is High.

### Step 5 – Create onSubmit Client Script
Prevent submission when Impact is High and Assigned To is empty.

### Step 6 – Create onCellEdit Client Script
Block direct State changes from Incident list editing.

### Step 7 – Functional Testing
Test:
- High Impact mandatory behavior
- Automatic Urgency update
- Urgency read-only behavior
- Failed save with empty Assigned To
- Successful save with Assigned To
- Reverse condition
- List edit blocking
- Form-based State update

## Implementation Resources
- ServiceNow Incident table
- UI Policies
- UI Policy Actions
- Client Scripts
- Incident form
- Incident list

## Completion Criteria
The project is considered complete when all configured controls behave according to the defined requirements and the testing scenarios produce the expected results.
