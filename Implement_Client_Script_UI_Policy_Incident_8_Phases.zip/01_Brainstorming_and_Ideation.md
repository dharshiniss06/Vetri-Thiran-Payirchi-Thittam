# Phase 1 – Brainstorming & Ideation

## Project Title
**Implement Client Script & UI Policy (Incident)**

## Problem Identification
Incident records require accurate and consistent data entry for effective triage, routing, reporting, SLA compliance, and resolution. Manual checking can result in incomplete or inconsistent information.

## Initial Idea
The project idea is to use ServiceNow client-side controls to enforce business rules directly on Incident forms and list views.

## Proposed Solution
The solution combines:
- UI Policies
- UI Policy Actions
- onChange Client Script
- onSubmit Client Script
- onCellEdit Client Script

These controls dynamically manage field behavior, automatically set values, validate required information, and prevent unauthorized list editing.

## Key Business Rules
1. When Impact is **1 – High**, Assignment group must be mandatory.
2. When Impact is **1 – High**, Urgency should automatically become **1 – High**.
3. When Impact is **1 – High**, Urgency should become read-only.
4. A High Impact Incident should not be saved when Assigned To is empty.
5. Direct list editing of the State field should be blocked.
6. When Impact is changed away from High, the applicable UI Policy behavior should be reversed.

## Expected Benefits
- Improved Incident data quality
- Consistent application of business rules
- Reduced incomplete submissions
- Better user guidance
- Controlled list editing
- Practical demonstration of ServiceNow client-side configuration
