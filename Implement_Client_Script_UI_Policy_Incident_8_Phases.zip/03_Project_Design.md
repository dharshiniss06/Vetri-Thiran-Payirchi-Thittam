# Phase 3 – Project Design

## Solution Architecture

The project uses multiple ServiceNow client-side controls working together.

```text
Incident Form / Incident List
          |
          v
   Impact = High?
      /        \
    Yes         No
     |           |
     v           v
High Impact   Reverse UI
UI Policy     Policy behavior
     |
     +-------------------+
     |                   |
     v                   v
Assignment Group     Urgency
Mandatory            Read-only
     |
     v
onChange Client Script
     |
     v
Urgency = High
     |
     v
onSubmit Validation
     |
     +---- Assigned To empty? ----+
     |                            |
    Yes                          No
     |                            |
     v                            v
Show error & block save       Save allowed

Incident List
     |
     v
State edited directly?
     |
     v
onCellEdit Client Script
     |
     v
Alert + callback(false)
```

## Component Design

| Component | Purpose | Trigger |
|---|---|---|
| High Impact Control | Makes Assignment group mandatory | Impact = High |
| UI Policy Action | Makes Urgency read-only | Impact = High |
| Auto set urgency for high impact | Sets Urgency to High | Impact changes |
| Prevent save if Assigned To missing | Validates Assigned To | Form submit |
| Prevent state change via list edit | Blocks State list editing | State cell edit |

## Data Flow

1. User changes Impact.
2. UI Policy evaluates the Impact condition.
3. Assignment group and Urgency behavior changes.
4. onChange Client Script sets Urgency to High when appropriate.
5. When the user submits the form, onSubmit validation checks Assigned To.
6. From the Incident list, onCellEdit prevents direct State modification.
7. State changes through the Incident form remain possible.
