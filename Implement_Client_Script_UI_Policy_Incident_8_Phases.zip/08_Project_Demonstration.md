# Phase 8 – Project Demonstration

## Project Name
**Implement Client Script & UI Policy (Incident)**

## Demonstration Objective

The demonstration should show the implemented ServiceNow configuration and prove that the defined Incident controls work correctly.

## Suggested Demo Sequence

### 1. Introduction
Explain:
- Project name
- Problem being addressed
- Purpose of the implementation

### 2. Show the UI Policy
Open:
**System UI → UI Policies**

Show:
- High Impact Control
- Table: Incident
- Condition: Impact is 1 – High
- Assignment group mandatory
- Reverse if false enabled

### 3. Show the Urgency UI Policy Action
Open the UI Policy Actions related list.

Show:
- Field: Urgency
- Read-only: true
- Visible: unchanged

### 4. Show the onChange Client Script
Open:
**System UI → Client Scripts**

Show:
- Auto set urgency for high impact
- Table: Incident
- Type: onChange
- Field: Impact
- Active: true

Demonstrate changing Impact to High and show that Urgency becomes High.

### 5. Show the onSubmit Client Script
Show:
- Prevent save if Assigned To missing
- Type: onSubmit
- Active: true

Demonstrate:
- Impact = High
- Assigned To empty
- Click Submit
- Error appears and save is prevented

Then select an Assigned To user and demonstrate a successful save.

### 6. Show the onCellEdit Client Script
Show:
- Prevent state change via list edit
- Type: onCellEdit
- Field: State
- Active: true

Open the Incident list and attempt to edit State directly. Show the alert and unchanged State value.

### 7. Demonstrate Form-Based State Update
Open the Incident form, change State, and click Update. Show that form-based State updates can be saved.

## Voice-Over Script

“Hello, this is our project, Implement Client Script & UI Policy for Incident Management in ServiceNow. The purpose of this project is to improve data integrity and enforce business rules directly at the user interface level.

First, we configured a High Impact Control UI Policy. When the Incident Impact is High, Assignment group becomes mandatory and the policy reverses when the condition is no longer true.

Next, we configured a UI Policy Action that makes Urgency read-only for High Impact incidents.

We also created an onChange Client Script. When Impact is changed to High, the script automatically sets Urgency to High.

The onSubmit Client Script validates Assigned To before saving. If the Incident has High Impact and Assigned To is empty, the system displays an error and prevents the record from being saved.

Finally, the onCellEdit Client Script prevents users from changing the State directly through list editing. State changes can instead be made from the Incident form.

These configurations demonstrate how UI Policies and Client Scripts can work together to enforce consistent Incident data entry and improve data quality.”

## Final Demo Checklist

- [ ] Project name explained
- [ ] Purpose explained
- [ ] UI Policy demonstrated
- [ ] Urgency UI Policy Action demonstrated
- [ ] onChange script demonstrated
- [ ] onSubmit validation demonstrated
- [ ] onCellEdit restriction demonstrated
- [ ] Successful save demonstrated
- [ ] Form-based State update demonstrated
- [ ] Voice-over recorded
- [ ] Video uploaded to Google Drive
- [ ] Google Drive sharing set to Anyone with the link
