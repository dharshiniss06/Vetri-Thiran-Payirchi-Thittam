# Phase 5 – Project Development

## 5.1 UI Policy – High Impact Control

**Table:** Incident  
**Name:** High Impact Control  
**Active:** true

**Condition:**
- Impact is 1 – High

**UI Policy Action – Assignment group:**
- Mandatory: true
- Reverse if false: true

## 5.2 UI Policy Action – Urgency

**Field:** Urgency  
**Read-only:** true  
**Visible:** Leave unchanged

This action makes Urgency read-only when Impact is High.

## 5.3 onChange Client Script – Auto Set Urgency

**Name:** Auto set urgency for high impact  
**Table:** Incident  
**Type:** onChange  
**Field:** Impact  
**Active:** true

```javascript
function onChange(control, oldValue, newValue, isLoading) {
    if (isLoading || newValue == '') {
        return;
    }

    if (newValue == '1') {
        g_form.setValue('urgency', '1');
        g_form.addInfoMessage('Urgency set to High for High impact incident.');
    }
}
```

## 5.4 onSubmit Client Script – Assigned To Validation

**Name:** Prevent save if Assigned To missing  
**Table:** Incident  
**Type:** onSubmit  
**Active:** true

```javascript
function onSubmit() {
    if (g_form.getValue('impact') == '1' &&
        g_form.getValue('assigned_to') == '') {

        g_form.showErrorBox(
            'assigned_to',
            'Assigned To is mandatory for High impact incidents.'
        );

        return false;
    }

    return true;
}
```

## 5.5 onCellEdit Client Script – State List Restriction

**Name:** Prevent state change via list edit  
**Table:** Incident  
**Type:** onCellEdit  
**Field:** State  
**Active:** true

```javascript
function onCellEdit(sysIDs, table, oldValues, newValue, callback) {
    alert('State cannot be updated using list editing. Please open the Incident.');
    callback(false);
}
```

## Development Result
The project implements three types of Client Scripts—onChange, onSubmit, and onCellEdit—together with UI Policy controls to manage Incident behavior.
